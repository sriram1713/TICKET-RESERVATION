import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class TicketBookingSystem 
{
	private static final String USER_DATA_FILE = "userdata.txt";
	private static HashMap<String, UserData> userData = new HashMap<>();
    	private static UserData currentUser;
    	public static void main(String args[])
  	{
       		loadUserDataFromFile();
	        JFrame f = new JFrame("Login/Register Example");
        	final JLabel label = new JLabel();
        	label.setBounds(20, 420, 400, 30);
        	final JPasswordField value = new JPasswordField();
        	value.setBounds(150, 75, 150, 30);
        	JLabel l1 = new JLabel("Username:");
        	l1.setBounds(50, 20, 80, 30);
        	JLabel l2 = new JLabel("Password:");
        	l2.setBounds(50, 75, 80, 30);
        	JButton b = new JButton("Login");
        	b.setBounds(150, 150, 100, 30);
        	JButton registerButton = new JButton("Register");
        	registerButton.setBounds(270, 150, 100, 30);
        	final JTextField text = new JTextField();
        	text.setBounds(150, 20, 150, 30);
        	f.add(value);
        	f.add(l1);
        	f.add(label);
        	f.add(l2);
        	f.add(b);
        	f.add(registerButton);
        	f.add(text);
        	f.setSize(500, 500);
        	f.setLayout(null);
        	f.setVisible(true);
	        b.addActionListener(new ActionListener() 
		{
            		public void actionPerformed(ActionEvent e) 
			{
                		String username = text.getText();
                		String password = new String(value.getPassword());
		                if (userData.containsKey(username) && userData.get(username).getPassword().equals(password)) 
				{
                    			currentUser = userData.get(username);
                    			label.setText("Login successful for user: " + currentUser.getUsername());
                    			showBookingForm(f, label);
                		} 
				else 
				{
					label.setText("Invalid username or password!");
                		}
            		}
        	});
        	registerButton.addActionListener(new ActionListener() 
		{
            		public void actionPerformed(ActionEvent e) 
			{
                		String username = text.getText();
                		String password = new String(value.getPassword());
		                if (userData.containsKey(username)) 
				{
                   		 	label.setText("Username already exists!");
                		} 
				else 
				{
					UserData newUser = new UserData(username, password);
                    			userData.put(username, newUser);
                    			saveUserDataToFile();
                    			currentUser = newUser;
                    			label.setText("Registration successful for user: " + currentUser.getUsername());
                    			showBookingForm(f, label);
                		}
            		}
        	});
    	}
	private static void showBookingForm(JFrame f, JLabel label) 
	{
        	f.getContentPane().removeAll();
        	f.repaint();
	        JLabel fromLabel = new JLabel("From:");
        	fromLabel.setBounds(50, 20, 80, 30);
        	JLabel toLabel = new JLabel("To:");
        	toLabel.setBounds(50, 70, 80, 30);
        	JLabel dateLabel = new JLabel("Date of Journey:");
        	dateLabel.setBounds(50, 120, 150, 30);
        	JLabel passengersLabel = new JLabel("Number of Passengers:");
        	passengersLabel.setBounds(50, 170, 150, 30);
        	JLabel busTypeLabel = new JLabel("Type of Bus:");
        	busTypeLabel.setBounds(50, 220, 100, 30);
	        JTextField fromField = new JTextField();
        	fromField.setBounds(200, 20, 200, 30);
        	JTextField toField = new JTextField();
       		toField.setBounds(200, 70, 200, 30);
        	JTextField dateField = new JTextField();
       		dateField.setBounds(200, 120, 200, 30);
        	JTextField passengersField = new JTextField();
        	passengersField.setBounds(200, 170, 50, 30);
	        String[] busTypes = {"Express", "Deluxe", "Luxury"};
        	JComboBox<String> busTypeComboBox = new JComboBox<>(busTypes);
        	busTypeComboBox.setBounds(200, 220, 150, 30);
	        JButton calculateButton = new JButton("Calculate Fare");
        	calculateButton.setBounds(200, 270, 150, 30);
	        JLabel fareLabel = new JLabel();
       		fareLabel.setBounds(50, 320, 300, 30);
	        JButton payButton = new JButton("Pay");
        	payButton.setBounds(150, 370, 100, 30);
        	JButton cancelButton = new JButton("Cancel");
        	cancelButton.setBounds(270, 370, 100, 30);
        	JLabel paymentStatus = new JLabel();
        	paymentStatus.setBounds(50, 420, 400, 30);
	        f.add(fromLabel);
        	f.add(toLabel);
        	f.add(dateLabel);
        	f.add(passengersLabel);
        	f.add(busTypeLabel);
        	f.add(fromField);
        	f.add(toField);
        	f.add(dateField);
        	f.add(passengersField);
        	f.add(busTypeComboBox);
        	f.add(calculateButton);
        	f.add(fareLabel);
        	f.add(payButton);
        	f.add(cancelButton);
        	f.add(paymentStatus);
	        calculateButton.addActionListener(new ActionListener() 
		{
            		public void actionPerformed(ActionEvent e) 
			{
                		String from = fromField.getText();
                		String to = toField.getText();
                		String date = dateField.getText();
                		int passengers = Integer.parseInt(passengersField.getText());
                		String busType = busTypeComboBox.getSelectedItem().toString();
		                if (from.isEmpty() || to.isEmpty() || date.isEmpty()) 
				{
                    			fareLabel.setText("Please fill in all the details!");
                		} 
				else 
				{
		                    	int fare = calculateFare(busType, passengers);
                    			fareLabel.setText("Total Fare:-"+ fare);
                		}
            		}
        	});

	        payButton.addActionListener(new ActionListener() 
		{
            		public void actionPerformed(ActionEvent e) 
			{
                		String from = fromField.getText();
                		String to = toField.getText();
                		String date = dateField.getText();
                		int passengers = Integer.parseInt(passengersField.getText());
                		String busType = busTypeComboBox.getSelectedItem().toString();
		                if (from.isEmpty() || to.isEmpty() || date.isEmpty()) 
				{
                    			paymentStatus.setText("Please fill in all the details!");
                		} 
				else 
				{
                    			int fare = calculateFare(busType, passengers);
                    			String fareMessage = "Total Fare " + fare;
                    			paymentStatus.setText(fareMessage);
                    			payButton.setEnabled(false);
                    			cancelButton.setEnabled(false);
		                        
                    			paymentStatus.setText("Please wait...");
                    			try 
					{
                        			Thread.sleep(3000); 
                    			} 
					catch (InterruptedException ex) 
					{
                        			ex.printStackTrace();
                    			}
                    			paymentStatus.setText("Transaction Successful!");
                    			ArrayList<Integer> seatNumbers = generateRandomSeatNumbers(passengers);
                    			String seatMessage = "Seat numbers: " + seatNumbers.toString();
                    			JOptionPane.showMessageDialog(null, seatMessage, "Random Seat Numbers", JOptionPane.INFORMATION_MESSAGE);
                		}
            		}
        	});
        	cancelButton.addActionListener(new ActionListener() 
		{
        		public void actionPerformed(ActionEvent e) 
			{
                		showBookingForm(f, label);
            		}
        	});
	        f.setSize(500, 500);
    	}
	private static ArrayList<Integer> generateRandomSeatNumbers(int passengers) 
	{
        	ArrayList<Integer> seatNumbers = new ArrayList<>();
        	Random random = new Random();
        	for (int i = 0; i < passengers; i++) 
		{
            		int seatNumber = random.nextInt(50) + 1; 
            		seatNumbers.add(seatNumber);
        	}
        	return seatNumbers;
    	}
    	private static int calculateFare(String busType, int passengers) 
	{
        	int baseFare;
        	switch (busType) 
		{
            		case "Express":
                		baseFare = 100;
                		break;
            		case "Deluxe":
                		baseFare = 150;
                		break;
            		case "Luxury":
                		baseFare = 200;
                		break;
            		default:
                		baseFare = 100;
                		break;
        	}
        	return baseFare * passengers;
    	}	
    	private static void loadUserDataFromFile() 
	{
        	try (BufferedReader reader = new BufferedReader(new FileReader(USER_DATA_FILE))) 
		{
            		String line;
            		while ((line = reader.readLine()) != null) 
			{
                		String[] parts = line.split(",");
                		if (parts.length == 2) 
				{
                    			String username = parts[0];
                    			String password = parts[1];
                    			UserData user = new UserData(username, password);
                    			userData.put(username, user);
                		}
            		}
        	} 
		catch (IOException e) 
		{
			System.out.println(e);
        	}
    	}
	private static void saveUserDataToFile() 
	{
        	try (BufferedWriter writer = new BufferedWriter(new FileWriter(USER_DATA_FILE))) 
		{
            		for (UserData user : userData.values()) 
			{
                		writer.write(user.toString());
                		writer.newLine();
            		}
        	} 
		catch (IOException e) 
		{
			System.out.println(e);
        	}
    	}
	static class UserData 
	{
        	private String username;
        	private String password;
	        public UserData(String username, String password) 
		{
            		this.username = username;
            		this.password = password;
        	}
	        public String getUsername() 
		{
            		return username;
        	}
        	public String getPassword() 
		{
            		return password;
        	}
	        @Override
        	public String toString() 
		{
            		return username + "," + password;
        	}
    	}
}
